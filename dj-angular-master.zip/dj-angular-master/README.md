# dj-angular
An implementation to combine Django and Angular.

Go to [this link]() to read the original blog here for this project.
