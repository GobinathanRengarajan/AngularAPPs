import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { SquareComponent } from './game/board-square/square.component';
import { BoardComponent } from './game/board/board.component';
import { GameService } from './game/game.service';
import { GameComponent } from './game/game.component';

@NgModule({
  imports: [BrowserModule],
  declarations: [ 
    AppComponent, 
    SquareComponent, 
    BoardComponent, 
    GameComponent,
  ],
  bootstrap: [AppComponent],
  providers: [GameService]
})
export class AppModule { }
