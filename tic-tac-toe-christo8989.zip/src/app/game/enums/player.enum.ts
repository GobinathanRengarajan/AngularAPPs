export enum Player {
  One,
  Two,
}