export enum Mark {
  nought,
  cross,
}