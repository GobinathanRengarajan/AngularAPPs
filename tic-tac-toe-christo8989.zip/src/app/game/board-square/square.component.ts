import { Component, Input } from '@angular/core';
import { BoardSquare } from "./board-square";
import { GameService } from "../game.service";

@Component({
  selector: 'game-square',
  templateUrl: "./square.component.html",
  styleUrls: ['./square.component.scss'],
})
export class SquareComponent {
  @Input() col: number;
  @Input() row: number;

  constructor(private service: GameService) { }

  select(): void {
    this.service.select(this.col, this.row);
  }
  
  get isSelected(): boolean {
    return this.service.isSelected(this.col, this.row);
  }

  get markClass(): string {
    return this.service.getMarkName(this.col, this.row);
  }

  get selectedClass(): string {
    return this.isSelected ? "selected" : "";
  }
}