import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { GameService } from "./game.service";
import { BoardSquare } from "./board-square/board-square";

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GameComponent {
  constructor(
    private service: GameService,
    private changeDetector: ChangeDetectorRef,
  ) { }

  get currentTurnText(): string {
    const player = this.service.getActivePlayer();
    return `Player ${player}'s turn.`;
  }

  get winnerText(): string {
    return this.service.winText;
  }

  reset(): void {
    this.service.reset();
    this.changeDetector.markForCheck();
  }
}