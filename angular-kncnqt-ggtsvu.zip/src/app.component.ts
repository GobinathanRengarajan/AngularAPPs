import { Component, ViewChild } from '@angular/core';
import { ToolbarService, LinkService, ImageService, HtmlEditorService, RichTextEditorComponent } from '@syncfusion/ej2-angular-richtexteditor';
import { enableRipple } from '@syncfusion/ej2-base';
enableRipple(true);

import { Grid, Page, Selection, RowDD } from '@syncfusion/ej2-grids';
import { DragEventArgs, ListBox } from '@syncfusion/ej2-angular-dropdowns';
import { TreeView } from '@syncfusion/ej2-navigations';


Grid.Inject(Page);


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  providers: [ToolbarService, LinkService, ImageService, HtmlEditorService]
})

export class AppComponent {
  private listboxEle: any;
  private editArea: any;
public listview : any
  private dragEleContent: string;

  @ViewChild('RTE', null) public rteObj: RichTextEditorComponent;

  public data: { [key: string]: Object }[] = [
    { text: 'Hennessey Venom', id: 'list-01', "htmlAttributes": { draggable: true } },
    { text: 'Bugatti Chiron', id: 'list-02', "htmlAttributes": { draggable: true } },
    { text: 'Bugatti Veyron Super Sport', id: 'list-03', "htmlAttributes": { draggable: true } }
  ];


public orderdetails: { [key: string]: Object }[] = [

   {
        OrderID: 10248,
        CustomerName: 'VINET',
        
    },
    {
        OrderID: 10249,
        CustomerName: 'TOMSP',
    },
    {
        OrderID: 10250,
        CustomerName: 'HANAR',
    },
    {
        OrderID: 10251,
        CustomerName: 'VICTE',
    },
    {
        OrderID: 10252,
        CustomerName: 'SUPRD',
    },
    {
        OrderID: 10253,
        CustomerName: 'HANAR',
    },
    {
        OrderID: 10254,
        CustomerName: 'CHOPS',
    },
    {
        OrderID: 10255,
        CustomerName: 'RICSU',
    },
    {
        OrderID: 10256,
        CustomerName: 'WELLI',
    },
    {
        OrderID: 10257,
        CustomerName: 'HILAA',
    }

]


   

  onCreate() {
      this.listview = new ListBox({
        dataSource: this.data
    });

    this.listview.appendTo('#test');




    let grid: Grid = new Grid(
        {
            dataSource: this.orderdetails,
            allowPaging: true,
            allowRowDragAndDrop: true,
            selectionSettings: { type: 'Multiple' },
            rowDropSettings: { targetID: 'DestGrid' },
            pageSettings: { pageCount: 2 },
            width: '49%',
            columns: [
                { field: 'OrderID', headerText: 'Order ID', width: 120, textAlign: 'Right' },
                { field: 'CustomerName', headerText: 'Customer Name', width: 135 },
                { field: 'OrderDate', headerText: 'Order Date', width: 130, format: 'yMd', textAlign: 'Right' }
            ]
        });
    grid.appendTo('#Grid');

    let destGrid: Grid = new Grid(
        {
            dataSource: [],
            allowPaging: true,
            allowRowDragAndDrop: true,
            selectionSettings: { type: 'Multiple' },
            rowDropSettings: { targetID: 'Grid' },
            pageSettings: { pageCount: 2 },
            width: '49%',
            columns: [
                { field: 'OrderID', headerText: 'Order ID', width: 120, textAlign: 'Right' },
                { field: 'CustomerName', headerText: 'Customer Name', width: 135 },
                { field: 'OrderDate', headerText: 'Order Date', width: 130, format: 'yMd', textAlign: 'Right' }
            ]
        });
    destGrid.appendTo('#DestGrid');


  }

  
}