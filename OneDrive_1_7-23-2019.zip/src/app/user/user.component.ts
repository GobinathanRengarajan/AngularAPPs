import { Component, OnInit, Input } from '@angular/core';
import { Router, } from "@angular/router";
import { Subscription } from 'rxjs';
import { ValidateService } from "src/app/validate.service";
import { freeApiService } from "src/app/freeapi.service";
import { Comments } from "src/app/comments";


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  
  username:string;
  isTrade: boolean = false;
  isNonTrade: boolean = false;
  checkAllTrades: boolean = false;
  public inEditMode = true;

  constructor(private router: Router,private _validateService:ValidateService,private _freeApiService: freeApiService) { }

lstcomments: any[];

  ngOnInit() {
     this.username=this._validateService.getUsername();
     this._freeApiService.getcomments()
     .subscribe
     (
       data =>
       {
             this.lstcomments = data;
       }

     );

     
  }
  get(id,postId,name,email,body) {
    alert('ID:' + id +' '+ '\n POSTID:'+ postId +' '+ '\n NAME:'+ name +' '+ '\n EMAIL:'+email+' '+ '\n BODY:'+body);
}
changeTradesByCategory(event) {
    if (event.target.name == 'trades') {
      this.isTrade = true
    }

    if (this.isTrade && this.checkAllTrades) {
      event.target.checked = true
    }
  }

allTrades(event) {
    const checked = event.target.checked;
    this.lstcomments.forEach(item => item.selected = checked);
  }
  selectedCheckBox() {
    //alert();
    
    // this.isDisable = true;
    var elements = (<HTMLInputElement[]><any>document.getElementsByName("chk"));
    console.log("test",elements);
    for (let i = 0; i < 500; i++) {
      console.log(i);
      if (elements[i].type == "checkbox") {
        if (elements[i].checked) {
          console.log("Checked", elements[i].checked);
         // var dis = (<HTMLInputElement[]><any>document.getElementsByName("allTrades"));
         // console.log(dis[i]);
          this.inEditMode = false;
        // this.inEditMode = true;
        //console.log(elements[i]);
        // elements[i].disabled;
          break;
        }
        else {
          console.log("Unchecked", elements[i].checked);
           //var dis = (<HTMLInputElement[]><any>document.getElementsByName("allTrades"));
          // dis[i].inEditMode = false;
         this.inEditMode = true;
         //elements[i].enabled;
        }
      }
    }
  }
}



