import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from "src/app/user/user.component";
import { LoginComponent } from "src/app/login/login.component";
import { LogoutComponent } from "src/app/logout/logout.component";

const routes: Routes = [
   { path: 'user', component: UserComponent },
  { path: 'login', component: LoginComponent },
   {path : 'logout', component : LogoutComponent},
   {
    path:'',
    redirectTo: '/login' ,
    pathMatch: 'full'
  }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
