import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {MatDialog} from '@angular/material'
import { FormBuilder } from "@angular/forms";
import { FormGroup, Validators } from "@angular/forms";
import { ValidateService } from "src/app/validate.service";
import { PasswordStrengthValidator } from "src/password-strength.validators";


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

rForm: FormGroup;
  post:any;
  name:string;
  password:string='';
  constructor(private fb: FormBuilder,private _validateService:ValidateService,private router: Router) {
    this.rForm=fb.group({
      'name' :['',Validators.required],
     'passwordtest' :['',[Validators.required,Validators.pattern('^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=[^0-9]*[0-9]).{8,}$')]],
     });
   }

  ngOnInit() {
  }
 validateUser(post)
{
  this.name=post.name;
  this.password=post.password;
 
 if(post.name == '' || post.password == '' ||post.password< 6 ||post.password>=10){
    alert("username or password is incorrect");
    }else {
      this.router.navigate(['user']);
      this._validateService.save(this.name);
    }


}
}



