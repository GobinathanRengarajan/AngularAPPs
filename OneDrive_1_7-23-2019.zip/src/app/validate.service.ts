import { Injectable } from '@angular/core';
@Injectable(({
    providedIn: 'root'
}) as any)
export class ValidateService {
    uname: string;
    save(username) {
        this.uname = username;
    }
    getUsername() {
        return this.uname;
    }
}