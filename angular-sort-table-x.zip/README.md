# angular-sort-table-x

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-sort-table-x)